"use strict"
var e=require("clock"),t=require("document"),i=require("user-settings")
function n(e){e<10&&(e="0"+e)
return e}var l=["sun","mon","tue","wed","thu","fri","sat"],a=t.getElementById("chara"),r="[Liam]",o=t.getElementById("background"),s=t.getElementById("overlay"),c=0,d=0,h=0,g=t.getElementById("menu")
g.style.visibility="hidden"
var m=t.getElementById("time")
t.getElementById("date")
e.default.granularity="minutes"
e.default.ontick=function(e){var t=e.date,a=t.getHours()
a="12h"===i.preferences.clockDisplay?a%12||12:n(a)
var r=n(t.getMinutes()),o=n(t.getDate()),s=l[t.getDay()]
m.text="".concat(a,":").concat(r," - ").concat(s," ").concat(o)}
a.addEventListener("mousedown",(function(){g.style.visibility="visible"
h=1}))
o.addEventListener("mousedown",(function(){g.style.visibility="hidden"
h=0}))
s.addEventListener("mousedown",(function(){if(1===h){g.style.visibility="hidden"
h=0}else{g.style.visibility="visible"
h=1}}))
var u=t.getElementById("menu-rect"),y=t.getElementById("menu-item1")
y.addEventListener("mousedown",(function(){if(1===h)if(2===d){r="[Bryce]"
a.href="characters/bryce.png"
if(1===c){B()
y.text=r
x.text="Enter radio..."
f.text="Change character"
d=0}else{B()
y.text=r
x.text="Kill"
f.text="Change character"
d=0}g.style.visibility="hidden"}else if(1===d){c=2
o.href="locations/sf.png"
s.href="overlays/overlay_sf.png"
s.width=336
s.height=336
g.style.visibility="hidden"
d=0
h=0
B()
y.text=r
x.text="Kill"
f.text="Change character"}}))
var x=t.getElementById("menu-item2")
x.addEventListener("mousedown",(function(){if(1===h)if(2===d){r="[Amelia]"
a.href="characters/amelia.png"
if(1===c){B()
y.text=r
x.text="Enter radio..."
f.text="Change character"
d=0}else{B()
y.text=r
x.text="Kill"
f.text="Change character"
d=0}g.style.visibility="hidden"}else if(1===d){c=3
o.href="locations/airy.png"
g.style.visibility="hidden"
d=0
h=0
B()
y.text=r
x.text="Kill"
f.text="Change character"}else if(0===c){console.log("Kill menu item clicked")
o.href="locations/waitingroom.png"
x.text="Enter radio..."
g.style.visibility="hidden"
c=1
d=0
s.width=0
s.height=0}else if(2===c){console.log("Kill menu item clicked")
o.href="locations/waitingroom.png"
x.text="Enter radio..."
g.style.visibility="hidden"
c=1
d=0
s.width=0
s.height=0}else if(3===c){console.log("Kill menu item clicked")
o.href="locations/waitingroom.png"
x.text="Enter radio..."
g.style.visibility="hidden"
c=1
d=0
s.width=0
s.height=0}else if(1===c&&0===d){console.log("hi")
b()
E.text="[Radio]"
v.text="Go to The Plane"
y.text="Go to S.F."
x.text="Go to Airy's World"
f.text="Back"
d=1}}))
var f=t.getElementById("menu-item3")
f.addEventListener("mousedown",(function(){console.log("Current menumode:",d)
if(1===h)if(1===d){console.log("Running menumode === 1 block")
B()
y.text=r
x.text="Enter radio..."
f.text="Change character"
d=0}else if(0===d){console.log("Running menumode === 0 block")
b()
E.text="[Character]"
v.text="Liam"
y.text="Bryce"
x.text="Amelia"
f.text="Back"
d=2}else if(2===d){console.log("Running menumode === 2 block")
B()
y.text=r
x.text="Enter radio..."
f.text="Change character"
d=0}}))
var v=t.getElementById("menu-item-extra1")
v.addEventListener("mousedown",(function(){if(1===h)if(1===d){console.log(d)
c=0
o.href="locations/plane.png"
g.style.visibility="hidden"
d=0
B()
y.text=r
x.text="Kill"
f.text="Change character"}else if(2===d){r="[Liam]"
a.href="characters/liam.png"
if(1===c){B()
y.text=r
x.text="Enter radio..."
f.text="Change character"
d=0}else{B()
y.text=r
x.text="Kill"
f.text="Change character"
d=0}g.style.visibility="hidden"}}))
var E=t.getElementById("menu-item-extra2")
function b(){u.y=110}function B(){u.y=180
E.text=""
v.text=""}
