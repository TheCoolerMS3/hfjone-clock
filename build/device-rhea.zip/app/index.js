"use strict"
var e=require("clock"),t=require("document"),h=require("user-settings")
function r(e){e<10&&(e="0"+e)
return e}var i=["sun","mon","tue","wed","thu","fri","sat"],n=t.getElementById("chara"),a=0,c=t.getElementById("background"),s=t.getElementById("overlay"),g=0,f=t.getElementById("myLabel")
t.getElementById("date")
e.default.granularity="minutes"
e.default.ontick=function(e){var t=e.date,n=t.getHours()
n="12h"===h.preferences.clockDisplay?n%12||12:r(n)
var a=r(t.getMinutes()),c=r(t.getDate()),s=i[t.getDay()]
f.text="".concat(n,":").concat(a," - ").concat(s," ").concat(c)}
n.addEventListener("mousedown",(function(){if(0===a){a=1
n.href="characters/announcer.jpeg"
n.width=95
n.height=135
n.x=120
n.y=155}else if(1===a){a=2
n.href="characters/blocky.png"
n.width=130
n.height=130
n.x=105
n.y=160}else if(2===a){a=3
n.href="characters/pin.png"
n.width=120
n.height=170
n.x=110
n.y=120}else if(3===a){a=4
n.href="characters/spongy.png"
n.width=190
n.height=130
n.x=75
n.y=160}else if(4===a){a=5
n.href="characters/david.png"
n.width=75
n.height=140
n.x=130
n.y=150}else if(5===a){a=6
n.href="characters/flower.png"
n.width=110
n.height=170
n.x=110
n.y=120}else if(6===a){a=7
n.href="characters/freesmart_van.png"
n.width=200
n.height=80
n.x=70
n.y=210}else if(7===a){a=8
n.href="characters/loser.png"
n.width=150
n.height=160
n.x=80
n.y=135}else if(8===a){a=9
n.href="characters/pin_idfb.png"
n.width=120
n.height=180
n.x=110
n.y=110}else if(9===a){a=10
n.href="characters/tlc.png"
n.width=190
n.height=130
n.x=75
n.y=160}else if(10===a){a=11
n.href="characters/tv.png"
n.width=160
n.height=160
n.x=90
n.y=130}else if(11===a){a=12
n.href="characters/two.png"
n.width=160
n.height=165
n.x=80
n.y=125}else if(12===a){a=13
n.href="characters/winner.png"
n.width=100
n.height=180
n.x=120
n.y=120}else if(13===a){a=14
n.href="characters/x.png"
n.width=190
n.height=130
n.x=75
n.y=160}else{a=0
n.href="characters/four.png"
n.width=160
n.height=175
n.x=80
n.y=120}}))
c.addEventListener("mousedown",(function(){if(0===g){g=1
c.href="locations/yoyleland.png"}else if(1===g){g=2
c.href="locations/brb.png"
s.href="overlays/overlay_brb.png"
s.width=336
s.height=336}else{g=0
c.href="locations/goiky.jpeg"}}))
s.addEventListener("mousedown",(function(){g=0
c.href="locations/goiky.jpeg"
s.href="overlays/overlay.png"
s.width=1
s.height=1}))
